const espIp = '192.168.63.136'; // Replace with your ESP's IP address
let recognition;
const speechSynthesis = window.speechSynthesis;

// Wake-Up Words and Command Keywords
const wakeUpWords = ["jarvis", "shinchan"];
const fanKeywords = ["fan on", "turn on fan", "switch on fan", "fan off", "turn off fan"];
const lightKeywords = ["light on", "turn on light", "switch on light", "light off", "turn off light"];
let isAwaitingCommand = false;

if ('webkitSpeechRecognition' in window) {
    recognition = new webkitSpeechRecognition();
    recognition.continuous = true;
    recognition.lang = 'en-US';

    // Recognition started
    recognition.onstart = () => updateStatus("Listening for Wake-Up Word...", true);

    // Recognition result
    recognition.onresult = (event) => {
        const transcript = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
        updateDetected(transcript);

        if (isAwaitingCommand) {
            handleCommand(transcript);
        } else if (wakeUpWords.some(word => transcript.includes(word))) {
            acknowledgeWakeUp();
        }
    };

    // Recognition error
    recognition.onerror = (event) => {
        console.error("Recognition Error:", event.error);
        updateStatus("Error: Voice recognition failed.", false);
    };

    // Recognition ended
    recognition.onend = () => {
        console.log("Recognition ended. Restarting...");
        recognition.start(); // Restart listening
    };
} else {
    alert("Web Speech API not supported in this browser.");
}

// Acknowledge wake-up word
function acknowledgeWakeUp() {
    const greetings = ["Hello there!", "Good day!", "Hi, how can I assist you?"];
    const response = `${greetings[Math.floor(Math.random() * greetings.length)]} Yes sir, what can I help you with?`;
    updateResponse(`Wake-Up Word Detected - ${response}`);
    speak(response);
    isAwaitingCommand = true;
    updateStatus("Listening for Command...", true);
}

// Handle commands
function handleCommand(command) {
    let url = null;
    let responseMessage = null;

    if (fanKeywords.some(keyword => command.includes("fan") && command.includes("on"))) {
        url = `http://${espIp}/fan/on`;
        responseMessage = "Okay sir, turning on the fan.";
    } else if (fanKeywords.some(keyword => command.includes("fan") && command.includes("off"))) {
        url = `http://${espIp}/fan/off`;
        responseMessage = "Okay sir, turning off the fan.";
    } else if (lightKeywords.some(keyword => command.includes("light") && command.includes("on"))) {
        url = `http://${espIp}/light/on`;
        responseMessage = "Okay sir, turning on the light.";
    } else if (lightKeywords.some(keyword => command.includes("light") && command.includes("off"))) {
        url = `http://${espIp}/light/off`;
        responseMessage = "Okay sir, turning off the light.";
    } else {
        responseMessage = "This feature is not yet implemented.";
    }

    if (responseMessage) {
        updateResponse(responseMessage);
        speak(responseMessage);
    }

    if (url) {
        sendRequest(url);
    } else {
        resetListeningState();
    }
}

// Send HTTP request
function sendRequest(url) {
    fetch(url)
        .then(response => {
            if (response.ok) {
                updateStatus("Command sent successfully!", false);
            } else {
                updateStatus("Error: Failed to send command.", false);
            }
        })
        .catch(error => {
            console.error("Communication Error:", error);
            updateStatus("Error: Unable to communicate with ESP.", false);
        });
}

// Speak text
function speak(message) {
    if (!speechSynthesis) return;

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = 'en-US';
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    speechSynthesis.cancel();
    speechSynthesis.speak(utterance);
}

// Update UI functions
function updateStatus(message, isActive) {
    document.getElementById('status').textContent = message;
    const bars = document.getElementById('bars');
    if (isActive) {
        bars.classList.remove('inactive');
        bars.classList.add('active');
    } else {
        bars.classList.remove('active');
        bars.classList.add('inactive');
    }
}

function updateDetected(message) {
    document.getElementById('detected').textContent = `Detected: "${message}"`;
}

function updateResponse(message) {
    document.getElementById('response').textContent = `Response: ${message}`;
}

function resetListeningState() {
    isAwaitingCommand = false;
    updateStatus("Listening for Wake-Up Word...", true);
}

// Start recognition
recognition.start();
